package com.example.eventregisteryapp.ui.rules;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import com.example.eventregisteryapp.R;
import com.example.eventregisteryapp.databinding.FragmentHomeBinding;
import com.example.eventregisteryapp.databinding.FragmentRulesBinding;
import com.example.eventregisteryapp.ui.home.HomeViewModel;

public class RulesFragment extends Fragment {

    private RulesViewModel rulesViewModel ;
private FragmentRulesBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
            ViewGroup container, Bundle savedInstanceState) {
        rulesViewModel =
                new ViewModelProvider(this).get(RulesViewModel.class);

    binding = FragmentRulesBinding.inflate(inflater, container, false);
    View root = binding.getRoot();
        WebView webView = binding.docView;
        webView.loadUrl("file:///android_asset/docs/doc1.html");
        final TextView textView = binding.docTitle;
        rulesViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        return root;
    }


@Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}